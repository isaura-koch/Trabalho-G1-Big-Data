--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 11.13 (Debian 11.13-1.pgdg90+1)
-- Dumped by pg_dump version 13.3

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE postgres;
--
-- Name: postgres; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE postgres WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'en_US.utf8';


ALTER DATABASE postgres OWNER TO postgres;

\connect postgres

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: DATABASE postgres; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON DATABASE postgres IS 'default administrative connection database';


--
-- Name: trabalho_g1; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA trabalho_g1;


ALTER SCHEMA trabalho_g1 OWNER TO postgres;

--
-- Name: cliente_pedido(numeric); Type: FUNCTION; Schema: trabalho_g1; Owner: postgres
--

CREATE FUNCTION trabalho_g1.cliente_pedido(numeric) RETURNS double precision
    LANGUAGE plpgsql
    AS $_$
DECLARE
	codigo_cliente ALIAS FOR $1;
	num_pedidos integer;
	
BEGIN
	num_pedidos = (SELECT COUNT(cod_pedido) FROM pedido WHERE cod_cliente = codigo_cliente );
	IF(num_pedidos != null) THEN
		RETURN num_pedidos;
	ELSE
		RAISE EXCEPTION 'O numero % do cliente não existe', num_pedidos
		USING HINT = 'Verifique o codigo do cliente';
	END IF;
	
END
$_$;


ALTER FUNCTION trabalho_g1.cliente_pedido(numeric) OWNER TO postgres;

--
-- Name: criar_pedido(timestamp without time zone, integer, integer); Type: PROCEDURE; Schema: trabalho_g1; Owner: postgres
--

CREATE PROCEDURE trabalho_g1.criar_pedido(in_data_pedido timestamp without time zone, in_cod_cliente integer, INOUT out_cod_ped integer)
    LANGUAGE plpgsql
    AS $$
BEGIN
	
		IF (SELECT status FROM cliente WHERE cod_cliente = in_cod_cliente) != 'I' THEN

			INSERT INTO pedido(cod_cliente, data_pedido, status)
			VALUES(in_cod_cliente, in_data_pedido, 'A') RETURNING cod_pedido INTO out_cod_ped;
		ELSE
			RAISE EXCEPTION 'O cliente de cód. % está inativo!', in_cod_cliente
			USING HINT = 'Selecione um cliente Ativo';
		END IF;
	END;
$$;


ALTER PROCEDURE trabalho_g1.criar_pedido(in_data_pedido timestamp without time zone, in_cod_cliente integer, INOUT out_cod_ped integer) OWNER TO postgres;

--
-- Name: criar_reserva(integer, integer, integer, character varying); Type: PROCEDURE; Schema: trabalho_g1; Owner: postgres
--

CREATE PROCEDURE trabalho_g1.criar_reserva(in_cod_espet integer, in_cod_sec integer, in_cod_ped integer, in_cadeira character varying)
    LANGUAGE plpgsql
    AS $$
	BEGIN
		IF EXISTS (SELECT cod_sessao FROM sessao WHERE cod_sessao = in_cod_sec) THEN
			
			IF EXISTS (SELECT cod_espetaculo FROM espetaculo WHERE cod_espetaculo = in_cod_espet) THEN
				
				INSERT INTO reserva(cod_pedido, cod_espetaculo, cod_sessao, cadeira)
				VALUES(in_cod_ped, in_cod_espet, in_cod_sec, in_cadeira);
			ELSE
				RAISE EXCEPTION 'Não existe espetaculo com o Cód. %', in_cod_espet
				USING HINT = 'Selecione um Cód. válido.';
			END IF;
			
		ELSE
			RAISE EXCEPTION 'Não existe sessão com o Cód. %', in_cod_sec
			USING HINT = 'Selecione um Cód. válido.';
		END IF;			
		
	END;
	$$;


ALTER PROCEDURE trabalho_g1.criar_reserva(in_cod_espet integer, in_cod_sec integer, in_cod_ped integer, in_cadeira character varying) OWNER TO postgres;

--
-- Name: criar_sessoes(integer, timestamp without time zone, integer, integer, numeric); Type: PROCEDURE; Schema: trabalho_g1; Owner: postgres
--

CREATE PROCEDURE trabalho_g1.criar_sessoes(in_cod_espet integer, in_inicio timestamp without time zone, in_cod_periodicidade integer, in_durac integer, in_preco numeric)
    LANGUAGE plpgsql
    AS $$
	BEGIN

		INSERT INTO sessao (cod_espetaculo, data_hora_inicio, duracao, preco, cod_periodicidade) 
		VALUES (in_cod_espet, in_inicio, in_durac, in_preco, in_cod_periodicidade);

	END
	$$;


ALTER PROCEDURE trabalho_g1.criar_sessoes(in_cod_espet integer, in_inicio timestamp without time zone, in_cod_periodicidade integer, in_durac integer, in_preco numeric) OWNER TO postgres;

--
-- Name: define_total_ingressos(integer, integer); Type: PROCEDURE; Schema: trabalho_g1; Owner: postgres
--

CREATE PROCEDURE trabalho_g1.define_total_ingressos(in_cod_sec integer, in_total_ing integer)
    LANGUAGE plpgsql
    AS $$
	BEGIN

		UPDATE sessao SET total_ingressos = in_total_ing 
		WHERE cod_sessao = in_cod_sec;

	END;
	$$;


ALTER PROCEDURE trabalho_g1.define_total_ingressos(in_cod_sec integer, in_total_ing integer) OWNER TO postgres;

--
-- Name: esp_cid_cli(numeric); Type: FUNCTION; Schema: trabalho_g1; Owner: postgres
--

CREATE FUNCTION trabalho_g1.esp_cid_cli(numeric) RETURNS double precision
    LANGUAGE plpgsql
    AS $_$
DECLARE
	num_cleinte ALIAS FOR $1;
	city integer;
	place integer;
	espetaculo integer;

BEGIN
	espetaculo = (SELECT cod_espetaculo FROM espetaculo WHERE cod_estabelecimento = (SELECT cod_estabelecimento FROM estabelecimento WHERE cod_cidade = (SELECT cod_cidade FROM cliente WHERE cod_cliente = num_cleinte)));
	IF(espetaculo) != null THEN
		RETURN espetaculo;
	ELSE 
		RAISE EXCEPTION 'Não há espetaculo na cidade do cliente %', num_cleinte
		USING HINT = 'Verifique o codigo do cliente';
	END IF;
END;
$_$;


ALTER FUNCTION trabalho_g1.esp_cid_cli(numeric) OWNER TO postgres;

--
-- Name: espetaculos_reservas(numeric); Type: FUNCTION; Schema: trabalho_g1; Owner: postgres
--

CREATE FUNCTION trabalho_g1.espetaculos_reservas(numeric) RETURNS double precision
    LANGUAGE plpgsql
    AS $_$
DECLARE
	num_pedido ALIAS FOR $1;
	espetaculo integer;

BEGIN
	espetaculo = (SELECT cod_espetaculo FROM reserva WHERE cod_pedido = num_pedido  );
	IF(espetaculo) != null THEN
		RETURN espetaculo;
	ELSE 
		RAISE EXCEPTION 'O codigo do pedido % está não existe!', num_pedido
		USING HINT = 'Verifique o codigo do pedido';
	END IF;
END;
$_$;


ALTER FUNCTION trabalho_g1.espetaculos_reservas(numeric) OWNER TO postgres;

--
-- Name: registra_notificacao(integer); Type: PROCEDURE; Schema: trabalho_g1; Owner: postgres
--

CREATE PROCEDURE trabalho_g1.registra_notificacao(in_cod_cliente integer)
    LANGUAGE plpgsql
    AS $$
	
	DECLARE
		--Declaração do cursor
		cod_pedido_existente INT;
	
	BEGIN
		
		--Preenchimento do cursor, usando o código do cliente fornecido
		FOR cod_pedido_existente IN
			SELECT p.cod_pedido FROM pedido p 
			WHERE cod_cliente = in_cod_cliente AND 
			data_pedido BETWEEN current_date - 30 AND current_date
			
		LOOP 
			--Insersão dos valores na tabela
			INSERT INTO notificacao (data_notificacao, cod_pedido, mensagem)
				SELECT current_date,
				cod_pedido_existente,
				'Total dos gastos: ' || 
					--Soma do valor das sessões, usando o cód. do pedido como base
					(SELECT SUM(preco) FROM sessao s
					JOIN reserva r ON s.cod_sessao = r.cod_sessao
					WHERE r.cod_pedido = cod_pedido_existente);
		END LOOP;

	END;
	$$;


ALTER PROCEDURE trabalho_g1.registra_notificacao(in_cod_cliente integer) OWNER TO postgres;

--
-- Name: reserva_assentos(numeric); Type: FUNCTION; Schema: trabalho_g1; Owner: postgres
--

CREATE FUNCTION trabalho_g1.reserva_assentos(numeric) RETURNS double precision
    LANGUAGE plpgsql
    AS $_$
DECLARE
	acento_code ALIAS FOR $1;
	cadeira_reservada integer;
	
BEGIN
	cadeira_reservada = (SELECT cadeira FROM reserva WHERE cod_reserva = acento_code );
	IF(cadeira_reservada != null) THEN
		RETURN cadeira_reservada;
	ELSE
		RAISE EXCEPTION 'A cadeira reservada % não existe!', acento_code
		USING HINT = 'Verifique o codigo da reserva';
		
	END IF; 
END
$_$;


ALTER FUNCTION trabalho_g1.reserva_assentos(numeric) OWNER TO postgres;

--
-- Name: sessao_ingresso(numeric); Type: FUNCTION; Schema: trabalho_g1; Owner: postgres
--

CREATE FUNCTION trabalho_g1.sessao_ingresso(numeric) RETURNS double precision
    LANGUAGE plpgsql
    AS $_$
DECLARE
	sessao_line ALIAS FOR $1;
	count_ingress1 integer;
	count_ingress2 integer;
BEGIN
	count_ingress1 = (SELECT total_ingressos FROM sessao WHERE cod_sessao = sessao_line );
	count_ingress2 = (SELECT ingressos_disponiveis FROM sessao WHERE cod_sessao = sessao_line );
	
	IF(count_ingress1 != null OR count_ingress2 != null) THEN
		RAISE NOTICE 'Ingressos totais: % | Inrgessos disponiveis: %', count_ingress1, count_ingress2;
		RETURN count_ingress1;
		
	ELSE
		RAISE EXCEPTION 'O codigo da sessao % está não existe!', sessao_line
		USING HINT = 'Verifique o codigo da sessao';
	
	END IF;
	
END
$_$;


ALTER FUNCTION trabalho_g1.sessao_ingresso(numeric) OWNER TO postgres;

SET default_tablespace = '';

--
-- Name: cidade; Type: TABLE; Schema: trabalho_g1; Owner: postgres
--

CREATE TABLE trabalho_g1.cidade (
    cod_cidade integer NOT NULL,
    nome character varying(50) NOT NULL,
    uf character(2) NOT NULL
);


ALTER TABLE trabalho_g1.cidade OWNER TO postgres;

--
-- Name: cidade_cod_cidade_seq; Type: SEQUENCE; Schema: trabalho_g1; Owner: postgres
--

ALTER TABLE trabalho_g1.cidade ALTER COLUMN cod_cidade ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME trabalho_g1.cidade_cod_cidade_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: cliente; Type: TABLE; Schema: trabalho_g1; Owner: postgres
--

CREATE TABLE trabalho_g1.cliente (
    cod_cliente integer NOT NULL,
    nome character varying(50) NOT NULL,
    sobrenome character varying(50) NOT NULL,
    cpf character varying(20) NOT NULL,
    endereco_entrega character varying(150) NOT NULL,
    cod_cidade integer NOT NULL,
    status character(1) DEFAULT 'A'::bpchar,
    CONSTRAINT cliente_status_ck CHECK ((status = ANY (ARRAY['A'::bpchar, 'I'::bpchar])))
);


ALTER TABLE trabalho_g1.cliente OWNER TO postgres;

--
-- Name: cliente_cod_cliente_seq; Type: SEQUENCE; Schema: trabalho_g1; Owner: postgres
--

ALTER TABLE trabalho_g1.cliente ALTER COLUMN cod_cliente ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME trabalho_g1.cliente_cod_cliente_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: espetaculo; Type: TABLE; Schema: trabalho_g1; Owner: postgres
--

CREATE TABLE trabalho_g1.espetaculo (
    cod_espetaculo integer NOT NULL,
    nome character varying(50),
    descricao character varying(100),
    cod_estabelecimento integer NOT NULL
);


ALTER TABLE trabalho_g1.espetaculo OWNER TO postgres;

--
-- Name: espetaculo_cod_espetaculo_seq; Type: SEQUENCE; Schema: trabalho_g1; Owner: postgres
--

ALTER TABLE trabalho_g1.espetaculo ALTER COLUMN cod_espetaculo ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME trabalho_g1.espetaculo_cod_espetaculo_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: estabelecimento; Type: TABLE; Schema: trabalho_g1; Owner: postgres
--

CREATE TABLE trabalho_g1.estabelecimento (
    cod_estabelecimento integer NOT NULL,
    nome character varying(50) NOT NULL,
    endereco character varying(50),
    tem_estacionamento boolean DEFAULT false,
    cod_tipo_espetaculo integer NOT NULL,
    cod_cidade integer NOT NULL,
    CONSTRAINT estab_estac_ck CHECK ((tem_estacionamento = ANY (ARRAY[true, false])))
);


ALTER TABLE trabalho_g1.estabelecimento OWNER TO postgres;

--
-- Name: estabelecimento_cod_estabelecimento_seq; Type: SEQUENCE; Schema: trabalho_g1; Owner: postgres
--

ALTER TABLE trabalho_g1.estabelecimento ALTER COLUMN cod_estabelecimento ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME trabalho_g1.estabelecimento_cod_estabelecimento_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: notificacao; Type: TABLE; Schema: trabalho_g1; Owner: postgres
--

CREATE TABLE trabalho_g1.notificacao (
    cod_notificacao integer NOT NULL,
    data_notificacao date,
    cod_pedido integer NOT NULL,
    mensagem text
);


ALTER TABLE trabalho_g1.notificacao OWNER TO postgres;

--
-- Name: notificacao_cod_notificacao_seq; Type: SEQUENCE; Schema: trabalho_g1; Owner: postgres
--

ALTER TABLE trabalho_g1.notificacao ALTER COLUMN cod_notificacao ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME trabalho_g1.notificacao_cod_notificacao_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: pedido; Type: TABLE; Schema: trabalho_g1; Owner: postgres
--

CREATE TABLE trabalho_g1.pedido (
    cod_pedido integer NOT NULL,
    cod_cliente integer NOT NULL,
    data_pedido date NOT NULL,
    data_cancelamento date,
    status character(1) DEFAULT 'A'::bpchar NOT NULL,
    CONSTRAINT pedido_status_check CHECK ((status = ANY (ARRAY['A'::bpchar, 'I'::bpchar])))
);


ALTER TABLE trabalho_g1.pedido OWNER TO postgres;

--
-- Name: pedido_cod_pedido_seq; Type: SEQUENCE; Schema: trabalho_g1; Owner: postgres
--

ALTER TABLE trabalho_g1.pedido ALTER COLUMN cod_pedido ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME trabalho_g1.pedido_cod_pedido_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: periodicidade; Type: TABLE; Schema: trabalho_g1; Owner: postgres
--

CREATE TABLE trabalho_g1.periodicidade (
    cod_periodicidade integer NOT NULL,
    descricao character varying(50) NOT NULL
);


ALTER TABLE trabalho_g1.periodicidade OWNER TO postgres;

--
-- Name: periodicidade_cod_periodicidade_seq; Type: SEQUENCE; Schema: trabalho_g1; Owner: postgres
--

ALTER TABLE trabalho_g1.periodicidade ALTER COLUMN cod_periodicidade ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME trabalho_g1.periodicidade_cod_periodicidade_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: reserva; Type: TABLE; Schema: trabalho_g1; Owner: postgres
--

CREATE TABLE trabalho_g1.reserva (
    cod_pedido integer NOT NULL,
    cod_espetaculo integer NOT NULL,
    cod_sessao integer NOT NULL,
    cod_reserva integer NOT NULL,
    cadeira character varying(10) NOT NULL
);


ALTER TABLE trabalho_g1.reserva OWNER TO postgres;

--
-- Name: reserva_cod_reserva_seq; Type: SEQUENCE; Schema: trabalho_g1; Owner: postgres
--

ALTER TABLE trabalho_g1.reserva ALTER COLUMN cod_reserva ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME trabalho_g1.reserva_cod_reserva_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: sessao; Type: TABLE; Schema: trabalho_g1; Owner: postgres
--

CREATE TABLE trabalho_g1.sessao (
    cod_sessao integer NOT NULL,
    cod_espetaculo integer NOT NULL,
    data_hora_inicio date,
    duracao integer NOT NULL,
    total_ingressos integer DEFAULT 0,
    ingressos_disponiveis integer DEFAULT 0,
    preco numeric NOT NULL,
    cod_periodicidade integer NOT NULL
);


ALTER TABLE trabalho_g1.sessao OWNER TO postgres;

--
-- Name: sessao_cod_sessao_seq; Type: SEQUENCE; Schema: trabalho_g1; Owner: postgres
--

ALTER TABLE trabalho_g1.sessao ALTER COLUMN cod_sessao ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME trabalho_g1.sessao_cod_sessao_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: tipo_espetaculo; Type: TABLE; Schema: trabalho_g1; Owner: postgres
--

CREATE TABLE trabalho_g1.tipo_espetaculo (
    cod_tipo_espetaculo integer NOT NULL,
    descricao character varying(50) NOT NULL
);


ALTER TABLE trabalho_g1.tipo_espetaculo OWNER TO postgres;

--
-- Name: tipo_espetaculo_cod_tipo_espetaculo_seq; Type: SEQUENCE; Schema: trabalho_g1; Owner: postgres
--

ALTER TABLE trabalho_g1.tipo_espetaculo ALTER COLUMN cod_tipo_espetaculo ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME trabalho_g1.tipo_espetaculo_cod_tipo_espetaculo_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Data for Name: cidade; Type: TABLE DATA; Schema: trabalho_g1; Owner: postgres
--

COPY trabalho_g1.cidade (cod_cidade, nome, uf) FROM stdin;
\.
COPY trabalho_g1.cidade (cod_cidade, nome, uf) FROM '$$PATH$$/2973.dat';

--
-- Data for Name: cliente; Type: TABLE DATA; Schema: trabalho_g1; Owner: postgres
--

COPY trabalho_g1.cliente (cod_cliente, nome, sobrenome, cpf, endereco_entrega, cod_cidade, status) FROM stdin;
\.
COPY trabalho_g1.cliente (cod_cliente, nome, sobrenome, cpf, endereco_entrega, cod_cidade, status) FROM '$$PATH$$/2975.dat';

--
-- Data for Name: espetaculo; Type: TABLE DATA; Schema: trabalho_g1; Owner: postgres
--

COPY trabalho_g1.espetaculo (cod_espetaculo, nome, descricao, cod_estabelecimento) FROM stdin;
\.
COPY trabalho_g1.espetaculo (cod_espetaculo, nome, descricao, cod_estabelecimento) FROM '$$PATH$$/2983.dat';

--
-- Data for Name: estabelecimento; Type: TABLE DATA; Schema: trabalho_g1; Owner: postgres
--

COPY trabalho_g1.estabelecimento (cod_estabelecimento, nome, endereco, tem_estacionamento, cod_tipo_espetaculo, cod_cidade) FROM stdin;
\.
COPY trabalho_g1.estabelecimento (cod_estabelecimento, nome, endereco, tem_estacionamento, cod_tipo_espetaculo, cod_cidade) FROM '$$PATH$$/2981.dat';

--
-- Data for Name: notificacao; Type: TABLE DATA; Schema: trabalho_g1; Owner: postgres
--

COPY trabalho_g1.notificacao (cod_notificacao, data_notificacao, cod_pedido, mensagem) FROM stdin;
\.
COPY trabalho_g1.notificacao (cod_notificacao, data_notificacao, cod_pedido, mensagem) FROM '$$PATH$$/2991.dat';

--
-- Data for Name: pedido; Type: TABLE DATA; Schema: trabalho_g1; Owner: postgres
--

COPY trabalho_g1.pedido (cod_pedido, cod_cliente, data_pedido, data_cancelamento, status) FROM stdin;
\.
COPY trabalho_g1.pedido (cod_pedido, cod_cliente, data_pedido, data_cancelamento, status) FROM '$$PATH$$/2987.dat';

--
-- Data for Name: periodicidade; Type: TABLE DATA; Schema: trabalho_g1; Owner: postgres
--

COPY trabalho_g1.periodicidade (cod_periodicidade, descricao) FROM stdin;
\.
COPY trabalho_g1.periodicidade (cod_periodicidade, descricao) FROM '$$PATH$$/2977.dat';

--
-- Data for Name: reserva; Type: TABLE DATA; Schema: trabalho_g1; Owner: postgres
--

COPY trabalho_g1.reserva (cod_pedido, cod_espetaculo, cod_sessao, cod_reserva, cadeira) FROM stdin;
\.
COPY trabalho_g1.reserva (cod_pedido, cod_espetaculo, cod_sessao, cod_reserva, cadeira) FROM '$$PATH$$/2989.dat';

--
-- Data for Name: sessao; Type: TABLE DATA; Schema: trabalho_g1; Owner: postgres
--

COPY trabalho_g1.sessao (cod_sessao, cod_espetaculo, data_hora_inicio, duracao, total_ingressos, ingressos_disponiveis, preco, cod_periodicidade) FROM stdin;
\.
COPY trabalho_g1.sessao (cod_sessao, cod_espetaculo, data_hora_inicio, duracao, total_ingressos, ingressos_disponiveis, preco, cod_periodicidade) FROM '$$PATH$$/2985.dat';

--
-- Data for Name: tipo_espetaculo; Type: TABLE DATA; Schema: trabalho_g1; Owner: postgres
--

COPY trabalho_g1.tipo_espetaculo (cod_tipo_espetaculo, descricao) FROM stdin;
\.
COPY trabalho_g1.tipo_espetaculo (cod_tipo_espetaculo, descricao) FROM '$$PATH$$/2979.dat';

--
-- Name: cidade_cod_cidade_seq; Type: SEQUENCE SET; Schema: trabalho_g1; Owner: postgres
--

SELECT pg_catalog.setval('trabalho_g1.cidade_cod_cidade_seq', 105, true);


--
-- Name: cliente_cod_cliente_seq; Type: SEQUENCE SET; Schema: trabalho_g1; Owner: postgres
--

SELECT pg_catalog.setval('trabalho_g1.cliente_cod_cliente_seq', 206, true);


--
-- Name: espetaculo_cod_espetaculo_seq; Type: SEQUENCE SET; Schema: trabalho_g1; Owner: postgres
--

SELECT pg_catalog.setval('trabalho_g1.espetaculo_cod_espetaculo_seq', 2206, true);


--
-- Name: estabelecimento_cod_estabelecimento_seq; Type: SEQUENCE SET; Schema: trabalho_g1; Owner: postgres
--

SELECT pg_catalog.setval('trabalho_g1.estabelecimento_cod_estabelecimento_seq', 200, true);


--
-- Name: notificacao_cod_notificacao_seq; Type: SEQUENCE SET; Schema: trabalho_g1; Owner: postgres
--

SELECT pg_catalog.setval('trabalho_g1.notificacao_cod_notificacao_seq', 6, true);


--
-- Name: pedido_cod_pedido_seq; Type: SEQUENCE SET; Schema: trabalho_g1; Owner: postgres
--

SELECT pg_catalog.setval('trabalho_g1.pedido_cod_pedido_seq', 5501, true);


--
-- Name: periodicidade_cod_periodicidade_seq; Type: SEQUENCE SET; Schema: trabalho_g1; Owner: postgres
--

SELECT pg_catalog.setval('trabalho_g1.periodicidade_cod_periodicidade_seq', 200, true);


--
-- Name: reserva_cod_reserva_seq; Type: SEQUENCE SET; Schema: trabalho_g1; Owner: postgres
--

SELECT pg_catalog.setval('trabalho_g1.reserva_cod_reserva_seq', 1210, true);


--
-- Name: sessao_cod_sessao_seq; Type: SEQUENCE SET; Schema: trabalho_g1; Owner: postgres
--

SELECT pg_catalog.setval('trabalho_g1.sessao_cod_sessao_seq', 1410, true);


--
-- Name: tipo_espetaculo_cod_tipo_espetaculo_seq; Type: SEQUENCE SET; Schema: trabalho_g1; Owner: postgres
--

SELECT pg_catalog.setval('trabalho_g1.tipo_espetaculo_cod_tipo_espetaculo_seq', 100, true);


--
-- Name: cidade cidade_nome_uf_key; Type: CONSTRAINT; Schema: trabalho_g1; Owner: postgres
--

ALTER TABLE ONLY trabalho_g1.cidade
    ADD CONSTRAINT cidade_nome_uf_key UNIQUE (nome, uf);


--
-- Name: cidade cidade_pkey; Type: CONSTRAINT; Schema: trabalho_g1; Owner: postgres
--

ALTER TABLE ONLY trabalho_g1.cidade
    ADD CONSTRAINT cidade_pkey PRIMARY KEY (cod_cidade);


--
-- Name: cliente cliente_pkey; Type: CONSTRAINT; Schema: trabalho_g1; Owner: postgres
--

ALTER TABLE ONLY trabalho_g1.cliente
    ADD CONSTRAINT cliente_pkey PRIMARY KEY (cod_cliente);


--
-- Name: espetaculo espetaculo_pkey; Type: CONSTRAINT; Schema: trabalho_g1; Owner: postgres
--

ALTER TABLE ONLY trabalho_g1.espetaculo
    ADD CONSTRAINT espetaculo_pkey PRIMARY KEY (cod_espetaculo);


--
-- Name: estabelecimento estabelecimento_pkey; Type: CONSTRAINT; Schema: trabalho_g1; Owner: postgres
--

ALTER TABLE ONLY trabalho_g1.estabelecimento
    ADD CONSTRAINT estabelecimento_pkey PRIMARY KEY (cod_estabelecimento);


--
-- Name: notificacao notificacao_pkey; Type: CONSTRAINT; Schema: trabalho_g1; Owner: postgres
--

ALTER TABLE ONLY trabalho_g1.notificacao
    ADD CONSTRAINT notificacao_pkey PRIMARY KEY (cod_notificacao);


--
-- Name: pedido pedido_pkey; Type: CONSTRAINT; Schema: trabalho_g1; Owner: postgres
--

ALTER TABLE ONLY trabalho_g1.pedido
    ADD CONSTRAINT pedido_pkey PRIMARY KEY (cod_pedido);


--
-- Name: periodicidade periodicidade_pkey; Type: CONSTRAINT; Schema: trabalho_g1; Owner: postgres
--

ALTER TABLE ONLY trabalho_g1.periodicidade
    ADD CONSTRAINT periodicidade_pkey PRIMARY KEY (cod_periodicidade);


--
-- Name: reserva reserva_pkey; Type: CONSTRAINT; Schema: trabalho_g1; Owner: postgres
--

ALTER TABLE ONLY trabalho_g1.reserva
    ADD CONSTRAINT reserva_pkey PRIMARY KEY (cod_reserva);


--
-- Name: reserva reserva_unique; Type: CONSTRAINT; Schema: trabalho_g1; Owner: postgres
--

ALTER TABLE ONLY trabalho_g1.reserva
    ADD CONSTRAINT reserva_unique UNIQUE (cod_espetaculo, cod_sessao, cadeira);


--
-- Name: sessao sessao_pkey; Type: CONSTRAINT; Schema: trabalho_g1; Owner: postgres
--

ALTER TABLE ONLY trabalho_g1.sessao
    ADD CONSTRAINT sessao_pkey PRIMARY KEY (cod_sessao);


--
-- Name: tipo_espetaculo tipo_espetaculo_pkey; Type: CONSTRAINT; Schema: trabalho_g1; Owner: postgres
--

ALTER TABLE ONLY trabalho_g1.tipo_espetaculo
    ADD CONSTRAINT tipo_espetaculo_pkey PRIMARY KEY (cod_tipo_espetaculo);


--
-- Name: cliente cliente_cidade_fk; Type: FK CONSTRAINT; Schema: trabalho_g1; Owner: postgres
--

ALTER TABLE ONLY trabalho_g1.cliente
    ADD CONSTRAINT cliente_cidade_fk FOREIGN KEY (cod_cidade) REFERENCES trabalho_g1.cidade(cod_cidade);


--
-- Name: notificacao cod_pedido_fk; Type: FK CONSTRAINT; Schema: trabalho_g1; Owner: postgres
--

ALTER TABLE ONLY trabalho_g1.notificacao
    ADD CONSTRAINT cod_pedido_fk FOREIGN KEY (cod_pedido) REFERENCES trabalho_g1.pedido(cod_pedido);


--
-- Name: espetaculo espetaculo_estab_fk; Type: FK CONSTRAINT; Schema: trabalho_g1; Owner: postgres
--

ALTER TABLE ONLY trabalho_g1.espetaculo
    ADD CONSTRAINT espetaculo_estab_fk FOREIGN KEY (cod_estabelecimento) REFERENCES trabalho_g1.estabelecimento(cod_estabelecimento);


--
-- Name: estabelecimento estab_tipo_espetaculo_fk; Type: FK CONSTRAINT; Schema: trabalho_g1; Owner: postgres
--

ALTER TABLE ONLY trabalho_g1.estabelecimento
    ADD CONSTRAINT estab_tipo_espetaculo_fk FOREIGN KEY (cod_tipo_espetaculo) REFERENCES trabalho_g1.tipo_espetaculo(cod_tipo_espetaculo);


--
-- Name: cliente estabelecimento_cidade_fk; Type: FK CONSTRAINT; Schema: trabalho_g1; Owner: postgres
--

ALTER TABLE ONLY trabalho_g1.cliente
    ADD CONSTRAINT estabelecimento_cidade_fk FOREIGN KEY (cod_cidade) REFERENCES trabalho_g1.cidade(cod_cidade);


--
-- Name: pedido pedido_cliente_fk; Type: FK CONSTRAINT; Schema: trabalho_g1; Owner: postgres
--

ALTER TABLE ONLY trabalho_g1.pedido
    ADD CONSTRAINT pedido_cliente_fk FOREIGN KEY (cod_cliente) REFERENCES trabalho_g1.cliente(cod_cliente);


--
-- Name: reserva reserva_espetaculo_fk; Type: FK CONSTRAINT; Schema: trabalho_g1; Owner: postgres
--

ALTER TABLE ONLY trabalho_g1.reserva
    ADD CONSTRAINT reserva_espetaculo_fk FOREIGN KEY (cod_espetaculo) REFERENCES trabalho_g1.espetaculo(cod_espetaculo);


--
-- Name: reserva reserva_pedido_fk; Type: FK CONSTRAINT; Schema: trabalho_g1; Owner: postgres
--

ALTER TABLE ONLY trabalho_g1.reserva
    ADD CONSTRAINT reserva_pedido_fk FOREIGN KEY (cod_pedido) REFERENCES trabalho_g1.pedido(cod_pedido);


--
-- Name: reserva reserva_sessao_fk; Type: FK CONSTRAINT; Schema: trabalho_g1; Owner: postgres
--

ALTER TABLE ONLY trabalho_g1.reserva
    ADD CONSTRAINT reserva_sessao_fk FOREIGN KEY (cod_sessao) REFERENCES trabalho_g1.sessao(cod_sessao);


--
-- Name: sessao sessao_espetaculo_fk; Type: FK CONSTRAINT; Schema: trabalho_g1; Owner: postgres
--

ALTER TABLE ONLY trabalho_g1.sessao
    ADD CONSTRAINT sessao_espetaculo_fk FOREIGN KEY (cod_espetaculo) REFERENCES trabalho_g1.espetaculo(cod_espetaculo);


--
-- Name: sessao sessao_periodicidade_fk; Type: FK CONSTRAINT; Schema: trabalho_g1; Owner: postgres
--

ALTER TABLE ONLY trabalho_g1.sessao
    ADD CONSTRAINT sessao_periodicidade_fk FOREIGN KEY (cod_periodicidade) REFERENCES trabalho_g1.periodicidade(cod_periodicidade);


--
-- PostgreSQL database dump complete
--

